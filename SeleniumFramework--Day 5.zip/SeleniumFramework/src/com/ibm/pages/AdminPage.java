package com.ibm.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class AdminPage

{
	@FindBy(xpath="//*[@id='side-menu']/li[5]/a/span")
	WebElement marketingEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[5]/ul/li[2]/a/i")
	WebElement mailEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/a")
	WebElement systemEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/ul/li[5]/a")
	WebElement weightclassEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/ul/li[1]/a")
	WebElement settingsEle;
	
	public AdminPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void clickonMarketingtab()
	{
		marketingEle.click();
	}
	
	public void clickonMailtab()
	{
		mailEle.click();
	}
	
	public void clickonSystemtab()
	{
		systemEle.click();
	}
	
	public void clickonWeightClasstab()
	{
		weightclassEle.click();
	}

	public void clickonsettingstab()
	{
		settingsEle.click();
	}
	
}
	